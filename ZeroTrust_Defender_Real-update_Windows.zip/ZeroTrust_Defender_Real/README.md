# ZeroTrust Defender & Analyzer — Real Windows Edition

Version 1.3 · Windows 10/11 · Local-only security dashboard · MIT License

---

## 繁體中文

### 1. 程式介紹

ZeroTrust Defender & Analyzer 是一套在 Windows 本機執行的安全監控與維護儀表板。它保留原始 HIPS／Process Hacker 風格介面，並透過本機 Python 後端連接 Windows PowerShell 與 Microsoft Defender。

後端只監聽 `127.0.0.1:8765`，不會讓區域網路或網際網路上的其他裝置直接連入。

### 2. 系統需求

- Windows 10 或 Windows 11
- Python 3.10 以上版本
- Microsoft Defender（狀態檢查及掃描功能需要）
- 建議使用系統管理員權限啟動
- Chrome、Edge 或其他現代瀏覽器

### 3. 安裝與啟動

1. 解壓縮 `ZeroTrust_Defender_Real_Windows.zip`。
2. 開啟解壓縮後的 `ZeroTrust_Defender_Real` 資料夾。
3. 雙擊 `START_ADMIN.bat`。
4. Windows 顯示 UAC 視窗時選擇「是」。
5. 瀏覽器會自動開啟 `http://127.0.0.1:8765/index.html`。
6. 使用完畢後關閉 PowerShell／命令視窗，即可停止本機後端。

如果無法使用管理員權限，也能執行 `Start-ZeroTrust.ps1`，但部分 Defender 或程序管理功能可能無法使用。

### 4. 真實功能

- 顯示目前 Windows 即時程序清單
- 每 15 秒自動更新程序資料
- 顯示程序名稱、PID、父程序及記憶體使用量
- 安全讀取程序路徑、命令列、建立時間等中繼資料
- 二次確認後強制終止選取的非保護程序
- 顯示 Microsoft Defender 防毒與即時防護狀態
- 顯示病毒碼更新時間及掃描狀態
- 執行 Microsoft Defender 快速掃描
- 清除 Windows DNS 快取
- 清除一天以前且未被鎖定的系統暫存檔
- 顯示操作成功、失敗及錯誤紀錄
- Base64 指令解碼及靜態風險特徵分析
- 繁體中文、English、日本語介面

### 5. 三語狀況報告

點擊頁面上方的「📋 狀況報告」，程式會讀取當下的真實系統狀態。每一份報告都會同時包含：

- 繁體中文
- English
- 日本語

報告內容包括 Windows 後端狀態、管理員權限、Defender 防毒狀態、即時防護、反間諜軟體、病毒碼時間、快速／完整掃描狀態、目前程序數量及警告。

點擊「下載 TXT」可儲存帶有 UTF-8 BOM 的文字檔，Windows 記事本可正常顯示中、英、日文字。Windows 回傳的特殊掃描值 `4294967295` 會顯示成「從未掃描／無資料」。

### 6. 安全模擬功能

PowerShell 記憶體注入、WMI 常駐及 Process Hollowing 三個攻擊按鈕只會改變網頁內的模擬狀態。它們不會：

- 下載或執行惡意程式
- 建立 WMI 後門
- 注入其他程序的記憶體
- 修改 Windows 開機常駐項目
- 製造真實 Process Hollowing

這些功能用於安全教育與介面展示。Comodo、Process Hacker／System Informer 本體並未包含在套件中。

### 7. 使用注意事項

- 終止程序前請先儲存其他程式中的工作。
- PID 0、PID 4、程式自身及 Windows 保護程序不允許終止。
- 程序掃描只讀取安全中繼資料，不會傾印受保護程序的原始記憶體或密碼。
- Defender 快速掃描可能需要數分鐘。
- 暫存檔清理會跳過使用中、鎖定或沒有權限的檔案。
- 請勿把 8765 埠轉發或公開到網路。

### 8. 故障排除

**顯示 Python 3 was not found**  
安裝 Python 3，安裝時勾選 `Add Python to PATH`，再重新執行 `START_ADMIN.bat`。

**瀏覽器顯示無法連線**  
確認 PowerShell 視窗仍然開啟。也可手動進入 `http://127.0.0.1:8765/index.html`。

**Defender 顯示 OFF 或 unavailable**  
確認 Windows Security 中的 Microsoft Defender 已啟用。若安裝了其他防毒軟體，Defender 可能處於被動模式。

**無法終止程序**  
該程序可能是 Windows 保護程序、已經結束，或目前沒有足夠權限。請使用 `START_ADMIN.bat` 重新啟動。

---

## English

### Overview and requirements

ZeroTrust Defender & Analyzer is a local Windows security monitoring and maintenance dashboard. It connects its browser interface to Windows PowerShell and Microsoft Defender through a Python backend bound only to `127.0.0.1:8765`.

Requirements: Windows 10/11, Python 3.10 or newer, Microsoft Defender for Defender features, and a modern browser. Administrator mode is recommended.

### Start the application

1. Extract the ZIP file.
2. Open the `ZeroTrust_Defender_Real` folder.
3. Double-click `START_ADMIN.bat`.
4. Accept the Windows UAC prompt.
5. The dashboard opens automatically in your browser.
6. Close the PowerShell/console window to stop the backend.

### Features

- Live Windows process inventory refreshed every 15 seconds
- Safe process metadata inspection
- Confirmed termination of non-protected processes
- Microsoft Defender antivirus, real-time protection, signature, and scan status
- Microsoft Defender Quick Scan
- DNS cache flush and cleanup of unlocked temporary files older than one day
- Base64 decoding and static risk-indicator analysis
- Operation and error logs
- Traditional Chinese, English, and Japanese interface
- Combined ZH/EN/JA status-report preview and UTF-8 TXT download

The attack controls are safe UI simulations. They do not create payloads, persistence, process injection, or process hollowing. Raw protected-process memory and credentials are never dumped.

If `4294967295` is returned by Windows for scan age, the report displays “Never scanned / unavailable.” Do not expose or forward TCP port 8765.

---

## 日本語

### 概要・動作環境

ZeroTrust Defender & Analyzer は、Windows PowerShell と Microsoft Defender に接続するローカル専用のセキュリティ監視・保守ダッシュボードです。バックエンドは `127.0.0.1:8765` のみで待ち受けます。

必要環境：Windows 10/11、Python 3.10 以降、Defender 機能用の Microsoft Defender、最新ブラウザ。管理者としての起動を推奨します。

### 起動手順

1. ZIP を展開します。
2. `ZeroTrust_Defender_Real` フォルダーを開きます。
3. `START_ADMIN.bat` をダブルクリックします。
4. Windows UAC を許可します。
5. ブラウザでダッシュボードが自動的に開きます。
6. 終了時は PowerShell／コンソール画面を閉じます。

### 主な機能

- 15秒ごとに更新される Windows プロセス一覧
- 安全なプロセスメタデータ検査
- 確認操作付きの非保護プロセス終了
- Microsoft Defender、リアルタイム保護、定義、スキャン状態
- Defender クイックスキャン
- DNS キャッシュ消去と1日より古い未ロック一時ファイルの削除
- Base64 復号と静的リスク指標分析
- 操作／エラーログ
- 繁體中文・English・日本語 UI
- 3言語を同時収録した状況レポートの画面表示と UTF-8 TXT 保存

攻撃ボタンは安全な UI シミュレーションです。ペイロード、WMI 永続化、メモリ注入、プロセス空洞化を実行しません。保護プロセスの生メモリや認証情報も取得しません。

Windows がスキャン経過日数として `4294967295` を返した場合、「未スキャン／データなし」と表示します。TCP ポート 8765 を外部公開しないでください。

---

## License and trademarks

MIT License · Copyright © 2026 ZeroTrust Defender Contributors. See `LICENSE` for the complete terms.

Microsoft, Windows, and Microsoft Defender are trademarks of Microsoft Corporation. Comodo and Process Hacker/System Informer are referenced only to describe the original demonstration concept. They are not bundled with or endorsed by this project. Other names and trademarks belong to their respective owners.
