$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$python = Get-Command py -ErrorAction SilentlyContinue
if ($python) { & py -3 app.py; exit $LASTEXITCODE }
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) { & python app.py; exit $LASTEXITCODE }
Write-Host 'Python 3 was not found. Install Python 3 from https://www.python.org/downloads/windows/' -ForegroundColor Red
Read-Host 'Press Enter to close'
