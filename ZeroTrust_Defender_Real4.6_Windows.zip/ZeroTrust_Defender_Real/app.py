"""Local-only Windows backend for ZeroTrust Defender & Analyzer."""
from __future__ import annotations

import ctypes
import json
import os
import re
import subprocess
import sys
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
HOST, PORT = "127.0.0.1", 8765
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
PROTECTED = {0, 4}


def ps(script: str, timeout: int = 60):
    if os.name != "nt":
        raise RuntimeError("This real system backend requires Windows 10/11.")
    cp = subprocess.run(
        ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True, text=True, timeout=timeout, creationflags=CREATE_NO_WINDOW,
    )
    if cp.returncode:
        raise RuntimeError((cp.stderr or cp.stdout or "PowerShell command failed").strip())
    return cp.stdout.strip()


def admin() -> bool:
    return os.name == "nt" and bool(ctypes.windll.shell32.IsUserAnAdmin())


def processes():
    raw = ps("Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,WorkingSetSize | ConvertTo-Json -Compress")
    rows = json.loads(raw or "[]")
    if isinstance(rows, dict): rows = [rows]
    result = []
    for p in rows:
        pid = int(p.get("ProcessId") or 0)
        result.append({"id": pid, "pid": pid, "parent": int(p.get("ParentProcessId") or 0),
                       "name": p.get("Name") or "Unknown", "cpu": 0,
                       "ram": f"{int(p.get('WorkingSetSize') or 0)/1048576:.1f} MB", "status": "normal", "strings": []})
    return result


def process_info(pid: int):
    if pid <= 0: raise ValueError("Invalid PID")
    script = f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId={pid}'; if(!$p){{throw 'Process not found'}}; $p | Select-Object Name,ProcessId,ParentProcessId,ExecutablePath,CommandLine,CreationDate | ConvertTo-Json -Compress"
    data = json.loads(ps(script))
    # Metadata inspection only: no raw cross-process memory dumping or credential extraction.
    vals = [f"{k}: {v}" for k, v in data.items() if v not in (None, "")]
    return {"strings": vals, "note": "Safe metadata scan (raw protected-process memory is intentionally not dumped)."}


def system_status():
    defender = {}
    try:
        raw = ps("Get-MpComputerStatus | Select-Object AntivirusEnabled,RealTimeProtectionEnabled,AntispywareEnabled,QuickScanAge,FullScanAge,AntivirusSignatureLastUpdated | ConvertTo-Json -Compress")
        defender = json.loads(raw)
    except Exception as e:
        defender = {"available": False, "error": str(e)}
    return {"windows": os.name == "nt", "admin": admin(), "defender": defender}


def cleanup():
    # Only documented, reversible/low-risk maintenance operations. No arbitrary WMI deletion.
    steps = []
    commands = [
        ("DNS cache", "Clear-DnsClientCache"),
        ("Temporary files", "$p=[IO.Path]::GetTempPath(); Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-1)} | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue"),
        ("Defender quick scan", "Start-MpScan -ScanType QuickScan"),
    ]
    for name, cmd in commands:
        try: ps(cmd, 600); steps.append({"name": name, "ok": True})
        except Exception as e: steps.append({"name": name, "ok": False, "error": str(e)})
    return {"ok": any(x["ok"] for x in steps), "steps": steps}


class Handler(SimpleHTTPRequestHandler):
    def _json(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data))); self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        try:
            path = urlparse(self.path).path
            if path == "/api/processes": return self._json(200, {"processes": processes()})
            if path == "/api/status": return self._json(200, system_status())
            if path.startswith("/api/process/"):
                pid = int(path.rsplit("/", 1)[-1]); return self._json(200, process_info(pid))
            return super().do_GET()
        except Exception as e: self._json(500, {"error": str(e)})

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", "0")); body = json.loads(self.rfile.read(length) or b"{}")
            path = urlparse(self.path).path
            if path == "/api/process/kill":
                pid = int(body.get("pid", 0))
                if pid in PROTECTED or pid == os.getpid(): raise ValueError("Protected PID cannot be terminated")
                if not body.get("confirm"): raise ValueError("Explicit confirmation is required")
                ps(f"Stop-Process -Id {pid} -Force -ErrorAction Stop")
                return self._json(200, {"ok": True, "pid": pid})
            if path == "/api/cleanup": return self._json(200, cleanup())
            self._json(404, {"error": "Not found"})
        except Exception as e: self._json(400, {"error": str(e)})

    def log_message(self, fmt, *args):
        print("[local]", fmt % args)


def main():
    if os.name != "nt": print("WARNING: UI opens, but real system APIs require Windows 10/11.")
    os.chdir(ROOT)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    threading.Timer(1, lambda: webbrowser.open(f"http://{HOST}:{PORT}/index.html")).start()
    print(f"ZeroTrust Defender running locally: http://{HOST}:{PORT}/index.html")
    print("Press Ctrl+C to stop.")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__ == "__main__": main()
